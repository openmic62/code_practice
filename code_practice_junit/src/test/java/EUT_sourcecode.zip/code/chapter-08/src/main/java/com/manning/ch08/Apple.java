package com.manning.ch08;

public class Apple {
	public boolean isEdible() { return true; }
}