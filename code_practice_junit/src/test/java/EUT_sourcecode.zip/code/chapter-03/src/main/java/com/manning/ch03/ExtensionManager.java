package com.manning.ch03;

public interface ExtensionManager {
	boolean isValid(String fileName);
}
