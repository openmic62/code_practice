package net.sf.jsptest.compiler.api;

/**
 * @author Lasse Koskela
 */
public interface JspExecution {

    String getRenderedResponse();
}
