#!/bin/sh

CONTACTS="Lasse Koskela <lasse.koskela@gmail.com>"
MODE=rsync_ssh

FROM=mavensync@shell.sourceforge.net:/home/groups/j/js/jsptest/htdocs/maven2
GROUP_DIR=net/sf/jsptest/
