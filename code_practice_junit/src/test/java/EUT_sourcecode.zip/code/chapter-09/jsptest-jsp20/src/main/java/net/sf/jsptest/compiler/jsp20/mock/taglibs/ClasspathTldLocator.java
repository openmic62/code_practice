/*
 * Copyright 2007 Lasse Koskela.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.sf.jsptest.compiler.jsp20.mock.taglibs;

import java.net.URL;

/**
 * @author Lasse Koskela
 */
public class ClasspathTldLocator implements TldLocator {

    public TldLocation find(String filename) {
        try {
            URL resource = getClass().getResource("/META-INF/" + filename);
            if (resource != null) {
                String filePath = extractFileUrlFrom(resource);
                String resourcePath = null;
                if ("jar".equals(resource.getProtocol())) {
                    resourcePath = "META-INF/" + filename;
                }
                return TldLocation.foundFromClassPath(filePath, resourcePath);
            }
        } catch (Exception ignored) {
            ignored.printStackTrace();
        }
        return TldLocation.notFound();
    }

    private String extractFileUrlFrom(URL resource) {
        String path = resource.getPath();
        if (path.indexOf("!") > -1) {
            path = path.substring(0, path.indexOf("!"));
        }
        return path;
    }
}
