package com.manning.ch04.config;

public class InvalidArgumentException extends RuntimeException {

}
