package com.manning.ch04.logs;

public interface WebService {
	void logError(String message) throws Exception;
}
