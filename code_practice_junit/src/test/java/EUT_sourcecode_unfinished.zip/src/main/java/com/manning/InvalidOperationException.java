package com.manning;

public class InvalidOperationException extends RuntimeException {
	public InvalidOperationException(String message) {}
}
