package com.manning;

public class TestUtil {
	public static void showProblem(String test, String message) {
		String template = "---%s---\n\t%s\n------------------";
		System.err.println(String.format(template, test, message));
	}

	public static String getCurrentMethodName() {
		return new Exception().getStackTrace()[1].getMethodName();
	}
}
