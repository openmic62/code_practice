package com.manning.ch03.reflection.anotherpackage;

import org.junit.Assert;
import org.junit.Test;

import com.manning.ch03.StubExtensionManager;
import com.manning.ch03.reflection.LogAnalyzer;

import java.lang.reflect.Constructor;

public class LogAnalyzerTest {
	@Test
	public void overridePrivateModifierOfField() {
		StubExtensionManager fake = new StubExtensionManager();
		fake.shouldExtensionsBeValid = true;

		LogAnalyzer log = instantiate(LogAnalyzer.class, fake);

		Assert.assertTrue(log.isValidLogFileName("validLogFile.ext"));
	}

	private <T> T instantiate(Class<T> target, Object argument) {
		try {
			Constructor<T> c = target.getDeclaredConstructor(
					argument.getClass());
			if (!c.isAccessible()) {
				c.setAccessible(true);
			}
			return c.newInstance(argument);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}
