package com.manning.ch01;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class GuiForTestingAClass extends JFrame {
	public static void main(String[] args) {
		new GuiForTestingAClass();
	}

	public GuiForTestingAClass() {
		super("My test app");
		getContentPane().setLayout(new BorderLayout());
		JButton testButton = new JButton("Test");
		testButton.setMaximumSize(new Dimension(100, 50));
		getContentPane().add(BorderLayout.NORTH, createSpacer(0, 70));
		getContentPane().add(BorderLayout.WEST, createSpacer(100, 50));
		getContentPane().add(BorderLayout.CENTER, testButton);
		getContentPane().add(BorderLayout.EAST, createSpacer(100, 50));
		getContentPane().add(BorderLayout.SOUTH, createSpacer(0, 70));
		setSize(300, 200);
		pack();
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	private Component createSpacer(final int width, final int height) {
		return new JComponent() {
			@Override
			public Dimension getPreferredSize() {
				return getMinimumSize();
			}

			@Override
			public Dimension getMinimumSize() {
				return new Dimension(width, height);
			}
		};
	}
}
