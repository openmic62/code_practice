package com.manning.ch02;

import static org.junit.Assert.fail;

import org.junit.Test;

public class SampleOfRunningMultipleTests {
	@Test
	public void thisIsTheFirstTest() throws Exception {
		// and it passes with flying colors!
	}

	@Test
	public void thisTestFails() throws Exception {
		fail("for demonstration purposes...");
	}

	@Test
	public void oneMoreTest() throws Exception {
		// just to show that all tests are run even if one fails
	}
}
