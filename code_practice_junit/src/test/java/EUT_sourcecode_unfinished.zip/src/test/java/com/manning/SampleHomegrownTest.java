package com.manning;

import org.junit.Test;

public class SampleHomegrownTest {
	@Test
	public void shouldReturnZeroWhenEmptyString() {
		// use Java's reflection API to get the current method's name
		// we could hard code the name, but it�s a useful technique to know
		String testName = TestUtil.getCurrentMethodName();
		System.out.println("running " + testName);
		try {
			SimpleParser p = new SimpleParser();
			int result = p.parseAndSum("");
			if (result != 0) {
				// Calling the helper method
				TestUtil
						.showProblem(testName,
								"Parse and sum should have returned 0 on an empty string");
			}
		} catch (Exception e) {
			TestUtil.showProblem(testName, e.toString());
		}
	}
}
