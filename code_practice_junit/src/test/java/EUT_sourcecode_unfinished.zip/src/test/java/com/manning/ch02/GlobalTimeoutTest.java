package com.manning.ch02;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.MethodRule;
import org.junit.rules.Timeout;

public class GlobalTimeoutTest {
	@Rule
	public MethodRule globalTimeout = new Timeout(100);

	@Test
	public void test1() throws InterruptedException {
		System.out.println("test1 started");
		Thread.sleep(1000);
	}

	@Test
	public void test2() throws InterruptedException {
		System.out.println("test2 started");
		Thread.sleep(1000);
	}
}
